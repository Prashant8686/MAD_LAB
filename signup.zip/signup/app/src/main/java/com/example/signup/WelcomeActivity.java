package com.example.signup;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class WelcomeActivity extends AppCompatActivity {

    TextView textWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        textWelcome = findViewById(R.id.welcomeText);

        // Receive the same key used in LoginActivity ("name")
        String user = getIntent().getStringExtra("name");

        if (user != null) {
            textWelcome.setText("Welcome, " + user + "!");
        } else {
            textWelcome.setText("Welcome!");
        }
    }
}
