package com.example.signup;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class LoginActivity extends AppCompatActivity {

    EditText usernameEditText, passwordEditText;
    Button buttonLogin, buttonGotoSignup;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonGotoSignup = findViewById(R.id.buttonGotoSignup);

        buttonLogin.setOnClickListener(v -> {
            String u = usernameEditText.getText().toString();
            String p = passwordEditText.getText().toString();

            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show();
            } else {
                Intent i = new Intent(this, WelcomeActivity.class);
                i.putExtra("name", u);
                startActivity(i);
            }
        });

        buttonGotoSignup.setOnClickListener(v ->
                startActivity(new Intent(this, SignupActivity.class)));
    }
}
