package com.example.signup;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignupActivity extends AppCompatActivity {

    EditText uname, pass;
    Button btnSignup, btnGotoLogin;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_signup);

        // Views
        uname = findViewById(R.id.usernameEditText);
        pass = findViewById(R.id.passwordEditText);
        btnSignup = findViewById(R.id.buttonSignup);
        btnGotoLogin = findViewById(R.id.buttonGotoLogin); // you missed this

        // SIGNUP button
        btnSignup.setOnClickListener(v -> {
            String u = uname.getText().toString();
            String p = pass.getText().toString();

            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                startActivity(new Intent(this, LoginActivity.class));
            }
        });

    }}