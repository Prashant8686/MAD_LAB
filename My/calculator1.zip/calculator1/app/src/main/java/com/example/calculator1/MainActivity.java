package com.example.calculator1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView inputText, resultText;
    String operator = "";
    double num1 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = findViewById(R.id.textView2);
        resultText = findViewById(R.id.textView);

        // Number buttons 0-9
        int[] numbers = {R.id.b0, R.id.b1, R.id.b2, R.id.b3, R.id.b4, R.id.b5, R.id.b6, R.id.b7, R.id.b8, R.id.b9};
        for (int i = 0; i < numbers.length; i++) {
            int finalI = i;
            findViewById(numbers[i]).setOnClickListener(v ->
                    inputText.setText(inputText.getText().toString() + finalI));
        }

        // Operator buttons
        findViewById(R.id.add).setOnClickListener(v -> setOperator("+"));
        findViewById(R.id.sub).setOnClickListener(v -> setOperator("-"));
        findViewById(R.id.mul).setOnClickListener(v -> setOperator("*"));
        findViewById(R.id.div).setOnClickListener(v -> setOperator("/"));

        // Clear
        findViewById(R.id.clear).setOnClickListener(v -> {
            inputText.setText("");
            resultText.setText("Result : --");
            operator = "";
            num1 = 0;
        });

        // Equals
        findViewById(R.id.equal).setOnClickListener(v -> {
            if (!operator.equals("") && !inputText.getText().toString().equals("")) {
                double num2 = Double.parseDouble(inputText.getText().toString());
                double res = 0;
                switch (operator) {
                    case "+": res = num1 + num2; break;
                    case "-": res = num1 - num2; break;
                    case "*": res = num1 * num2; break;
                    case "/": res = num2 != 0 ? num1 / num2 : 0; break;
                }
                resultText.setText("Result : " + res);
                inputText.setText("");
                operator = "";
            }
        });
    }

    // Set operator
    private void setOperator(String op) {
        if (!inputText.getText().toString().equals("")) {
            num1 = Double.parseDouble(inputText.getText().toString());
            operator = op;
            inputText.setText("");
        }
    }
}
